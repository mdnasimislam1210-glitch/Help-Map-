package com.nm.Helpmap.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nm.Helpmap.R
import com.nm.Helpmap.core.FirebaseSession
import com.nm.Helpmap.databinding.ActivitySplashBinding
import com.nm.Helpmap.ui.home.HomeActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycleScope.launch { runStartup() }
    }

    private suspend fun runStartup() {
        val startedAt = SystemClock.elapsedRealtime()
        binding.tvStatus.setText(R.string.splash_connecting)

        val state = FirebaseSession.ensureSignedIn()

        // Keep the animation on screen long enough to be seen.
        val elapsed = SystemClock.elapsedRealtime() - startedAt
        if (elapsed < MIN_SPLASH_MS) delay(MIN_SPLASH_MS - elapsed)

        binding.tvStatus.setText(
            if (state == FirebaseSession.State.ONLINE) R.string.splash_ready
            else R.string.splash_offline
        )

        // Swap loader for the success checkmark.
        binding.lottieLoader.visibility = View.INVISIBLE
        binding.lottieSuccess.visibility = View.VISIBLE
        binding.lottieSuccess.playAnimation()
        delay(SUCCESS_MS)

        startActivity(
            Intent(this, HomeActivity::class.java)
                .putExtra(HomeActivity.EXTRA_ONLINE, state == FirebaseSession.State.ONLINE)
        )
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    private companion object {
        const val MIN_SPLASH_MS = 2200L
        const val SUCCESS_MS = 1000L
    }
}
