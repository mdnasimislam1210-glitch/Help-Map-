package com.nm.Helpmap.ui.home

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.nm.Helpmap.R
import com.nm.Helpmap.core.FirebaseSession
import com.nm.Helpmap.databinding.ActivityHomeBinding
import com.nm.Helpmap.databinding.ItemCategoryBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    private data class Category(val emoji: String, val labelRes: Int)

    private val categories = listOf(
        Category("🏥", R.string.cat_hospitals),
        Category("💊", R.string.cat_pharmacies),
        Category("🚑", R.string.cat_ambulance),
        Category("🩸", R.string.cat_blood_oxygen),
        Category("❤️", R.string.cat_donate),
        Category("💬", R.string.cat_messages)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupStatusChip(intent.getBooleanExtra(EXTRA_ONLINE, false))
        setupSos()
        setupCategories()
    }

    private fun setupStatusChip(online: Boolean) {
        if (online) {
            val shortId = FirebaseSession.uid?.take(6) ?: "------"
            binding.tvStatus.text = getString(R.string.status_online, shortId)
            binding.statusDot.setBackgroundResource(R.drawable.bg_dot_green)
        } else {
            binding.tvStatus.setText(R.string.status_offline)
            binding.statusDot.setBackgroundResource(R.drawable.bg_dot_red)
        }
    }

    private fun setupSos() {
        binding.sosButton.setOnClickListener {
            Snackbar.make(binding.root, R.string.sos_hint, Snackbar.LENGTH_SHORT).show()
        }
        // Hold to call: prevents accidental calls. ACTION_DIAL needs no permission.
        binding.sosButton.setOnLongClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$EMERGENCY_NUMBER")))
            true
        }
    }

    private fun setupCategories() {
        val grid = binding.categoryGrid
        val inflater = LayoutInflater.from(this)
        val margin = (6 * resources.displayMetrics.density).toInt()

        categories.forEach { cat ->
            val item = ItemCategoryBinding.inflate(inflater, grid, false)
            item.tvEmoji.text = cat.emoji
            item.tvLabel.setText(cat.labelRes)

            item.root.layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                setMargins(margin, margin, margin, margin)
            }
            item.root.setOnClickListener {
                Snackbar.make(
                    binding.root,
                    getString(R.string.coming_next, getString(cat.labelRes)),
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            grid.addView(item.root)
        }
    }

    companion object {
        const val EXTRA_ONLINE = "extra_online"
        // 999 is Malaysia's emergency number (112 also works from mobiles).
        private const val EMERGENCY_NUMBER = "999"
    }
}
