package com.nm.Helpmap.core

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

object FirebaseSession {

    enum class State { ONLINE, OFFLINE }

    private const val TAG = "FirebaseSession"
    private const val TIMEOUT_MS = 7000L

    val uid: String? get() = FirebaseAuth.getInstance().currentUser?.uid

    /** Signs in anonymously if there is no session. Never throws; falls back to OFFLINE. */
    suspend fun ensureSignedIn(): State {
        val result = withTimeoutOrNull(TIMEOUT_MS) {
            try {
                val auth = FirebaseAuth.getInstance()
                if (auth.currentUser == null) {
                    auth.signInAnonymously().await()
                }
                State.ONLINE
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Sign-in failed: ${e.message}")
                State.OFFLINE
            }
        }
        return result ?: State.OFFLINE
    }
}
