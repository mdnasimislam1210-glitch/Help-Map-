# Help Map (com.nm.Helpmap)

## Run it
1. Firebase Console -> Project settings -> Your apps -> com.nm.Helpmap -> download `google-services.json`
   and put it in `app/google-services.json`.
2. Firebase Console: enable Authentication -> Anonymous, and create a Firestore database.
3. Open this folder in Android Studio (Koala or newer, JDK 17), let Gradle sync, press Run.
   Build APK: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Restrict your API key (Google Cloud Console) to package com.nm.Helpmap + your SHA-1.
